﻿using Sitecore.XConnect;
using Sitecore.XConnect.Client;
using Sitecore.XConnect.Schema;
using System;
using System.Threading.Tasks;
using Sitecore.XConnect.Client.WebApi;
using Sitecore.Xdb.Common.Web;
using Sitecore.XConnect.Collection.Model;
using System.Collections.Generic;
using Sitecore.Xdb.Common.Web;
using System.Net;

namespace MyxConnectProgram
{
    public class Program
    {
        private static void Main(string[] args)
        {
            MainAsync(args).ConfigureAwait(false).GetAwaiter().GetResult();
        }
        private static async Task MainAsync(string[] args)
        {
            var options = CertificateHttpClientHandlerModifierOptions.Parse("StoreName=My;StoreLocation=LocalMachine;FindType=FindByThumbprint;FindValue=864B202E730AF123AB857EE99824CB276B4866F1");
            var certificateModifier = new CertificateHttpClientHandlerModifier(options);
            var clientModifiers = new List<IHttpClientModifier>();
            var timeoutClientModifier = new TimeoutHttpClientModifier(new TimeSpan(0, 0, 20));
            clientModifiers.Add(timeoutClientModifier);
            var collectionClient = new CollectionWebApiClient(new Uri("https://XP9p2.xconnect/odata"), clientModifiers, new[] { certificateModifier });
            var searchClient = new SearchWebApiClient(new Uri("https://XP9p2.xconnect/odata"), clientModifiers, new[] { certificateModifier });
            var configurationClient = new ConfigurationWebApiClient(new Uri("https://XP9p2.xconnect/configuration"), clientModifiers, new[] { certificateModifier });
            var cfg = new XConnectClientConfiguration(new XdbRuntimeModel(CollectionModel.Model), collectionClient, searchClient, configurationClient);

            try
            {
                //If you are getting TLS Protocol issue, then uncomment below line
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls | SecurityProtocolType.Tls12;
                await cfg.InitializeAsync();
            }
            catch (XdbModelConflictException ce)
            {
                Console.WriteLine("ERROR:" + ce.Message);
                return;
            }
            using (var client = new XConnectClient(cfg))
            {
                Console.WriteLine("Connected:");
                AddContacts(client);
                Console.WriteLine("Added");
            }

            Console.ReadLine();
        }

        /// <summary>
        /// Create a new contact in xConnect with a new identifier named twitter
        /// </summary>
        /// <param name="client"></param>
        private static void AddContacts(XConnectClient client)
        {
            var identifiers = new ContactIdentifier[]
               {
                    new ContactIdentifier("twitter", "genmillstwitter", ContactIdentifierType.Known),
                    new ContactIdentifier("domain", "genmillsdomain", ContactIdentifierType.Known)
               };
            var contact = new Contact(identifiers);

            var personalInfoFacet = new PersonalInformation
            {
                FirstName = "General",
                LastName = "Mills",
                
            };
            client.SetFacet<PersonalInformation>(contact, PersonalInformation.DefaultFacetKey, personalInfoFacet);

            var emailFacet = new EmailAddressList(new EmailAddress("genmills@mumbai.com", true), "twitter");
            client.SetFacet<EmailAddressList>(contact, EmailAddressList.DefaultFacetKey, emailFacet);

            client.AddContact(contact);
            client.Submit();
        }
    }
}